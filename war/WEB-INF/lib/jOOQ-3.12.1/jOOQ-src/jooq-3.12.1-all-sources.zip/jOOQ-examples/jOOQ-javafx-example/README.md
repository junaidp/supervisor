Thanks for downloading jOOQ.
Please visit http://www.jooq.org for more information.

To install and run this example, simply check it out and run the following Maven command

```
$ pwd
/path/to/checkout/dir
$ cd jOOQ-examples/jOOQ-javafx-example
...
$ mvn clean install
```