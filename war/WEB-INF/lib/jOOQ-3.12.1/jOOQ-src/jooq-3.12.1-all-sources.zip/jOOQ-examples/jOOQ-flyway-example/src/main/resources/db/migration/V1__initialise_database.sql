DROP SCHEMA flyway_test IF EXISTS;

CREATE SCHEMA flyway_test;